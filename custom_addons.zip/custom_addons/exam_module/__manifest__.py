{
    "name": "Exam Module",
    "summary": "Exam Module",
    "author": "Mervvin",
    "version": "17.0.1.0.1",
    'depends': ['student_management'],
    "data": [
        'data/sequence.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/exam_views.xml',
        'views/exam_registration.xml',
        'views/center_management_views.xml',
        'menu_views.xml'
    ],
    "demo": [],
}
