{
    "name": "Student",
    "summary": "Student",
    "author": "Mervvin",
    "version": "17.0.1.0.1",
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/student_views.xml',
        'menu_views.xml'
    ],
    "demo": [],
}
